const express = require("express");
const router = express.Router();
const PortfolioItem = require("../models/PortfolioItem");
const nodemailer = require("nodemailer");
require("dotenv").config();

// Configure Nodemailer
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Helper function to send emails
function sendEmail(to, subject, text) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject,
    text,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Error sending email:", error);
    } else {
      console.log("Email sent:", info.response);
    }
  });
}

// Render portfolio page
router.get("/", async (req, res) => {
  try {
    const portfolioItems = await PortfolioItem.find();
    res.render("portfolio", { portfolioItems });
  } catch (error) {
    console.error("Error loading portfolio:", error);
    res.status(500).send("Server error");
  }
});

// Create a new portfolio item
router.post("/", async (req, res) => {
  try {
    const { title, description, images } = req.body;

    if (!title || !description || !images || images.length < 3) {
      return res.status(400).json({
        error: "All fields are required and at least 3 images are needed.",
      });
    }

    const newPortfolioItem = new PortfolioItem({
      title,
      description,
      images,
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    await newPortfolioItem.save();

    // Send email notification
    sendEmail(
      "a2n19a2n@gmail.com",
      "New Portfolio Item Created",
      `A new portfolio item titled "${title}" has been created.`
    );

    res.status(201).json(newPortfolioItem);
  } catch (error) {
    console.error("Error creating portfolio item:", error);
    res.status(500).json({ error: "Error creating portfolio item" });
  }
});

// Update a portfolio item
router.put("/:id", async (req, res) => {
  try {
    const { title, description, images } = req.body;

    if (!title || !description || !images || images.length < 3) {
      return res.status(400).json({
        error: "All fields are required and at least 3 images are needed.",
      });
    }

    const updatedPortfolioItem = await PortfolioItem.findByIdAndUpdate(
      req.params.id,
      { title, description, images, updatedAt: new Date() },
      { new: true }
    );

    if (!updatedPortfolioItem) {
      return res.status(404).json({ error: "Portfolio item not found" });
    }

    // Send email notification
    sendEmail(
      "a2n19a2n@gmail.com",
      "Portfolio Item Updated",
      `The portfolio item titled "${title}" has been updated.`
    );

    res.json(updatedPortfolioItem);
  } catch (error) {
    console.error("Error updating portfolio item:", error);
    res.status(500).json({ error: "Error updating portfolio item" });
  }
});

// Delete a portfolio item
router.delete("/:id", async (req, res) => {
  try {
    const deletedPortfolioItem = await PortfolioItem.findByIdAndDelete(
      req.params.id
    );

    if (!deletedPortfolioItem) {
      return res.status(404).json({ error: "Portfolio item not found" });
    }

    // Send email notification
    sendEmail(
      "a2n19a2n@gmail.com",
      "Portfolio Item Deleted",
      `The portfolio item titled "${deletedPortfolioItem.title}" has been deleted.`
    );

    res.json({ message: "Portfolio item deleted successfully" });
  } catch (error) {
    console.error("Error deleting portfolio item:", error);
    res.status(500).json({ error: "Error deleting portfolio item" });
  }
});

// API to fetch all portfolio items
router.get("/all", async (req, res) => {
  try {
    const portfolioItems = await PortfolioItem.find();
    res.json(portfolioItems);
  } catch (error) {
    console.error("Error fetching portfolio items:", error);
    res.status(500).json({ error: "Error fetching portfolio items" });
  }
});

module.exports = router;
