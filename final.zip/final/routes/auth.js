const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");
const speakeasy = require("speakeasy");
const QRCode = require("qrcode");
const User = require("../models/User");
require("dotenv").config();

const router = express.Router();

// Configure Nodemailer
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Helper function to send emails
function sendEmail(to, subject, text) {
  const mailOptions = { from: process.env.EMAIL_USER, to, subject, text };
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) console.error("Error sending email:", error);
    else console.log("Email sent:", info.response);
  });
}

// User registration
router.post("/register", async (req, res) => {
  try {
    const {
      username,
      password,
      firstName,
      lastName,
      age,
      gender,
      twoFactorEnabled,
    } = req.body;

    // Check if the username is already taken
    const existingUser = await User.findOne({ username });
    if (existingUser)
      return res.status(400).json({ error: "Username is already taken" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      username,
      password: hashedPassword,
      firstName,
      lastName,
      age,
      gender,
      twoFactorEnabled,
    });

    // Set up 2FA if enabled
    if (twoFactorEnabled) {
      const secret = speakeasy.generateSecret();
      user.twoFactorSecret = secret.base32;
      const qrCodeURL = await QRCode.toDataURL(secret.otpauth_url);

      await user.save();
      sendEmail(
        username,
        "Welcome!",
        `Hello, ${firstName}! Welcome to our platform!`
      );

      return res.status(201).json({
        message:
          "User registered successfully. Scan the QR code for 2FA setup.",
        qrCodeURL,
      });
    }

    // Save the user without 2FA
    await user.save();
    sendEmail(
      username,
      "Welcome!",
      `Hello, ${firstName}! Welcome to our platform!`
    );

    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ error: "Registration error" });
  }
});

// User login
router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ error: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      user.loginAttempts = (user.loginAttempts || 0) + 1;
      await user.save();

      if (user.loginAttempts >= 3) {
        sendEmail(
          username,
          "Failed Login Attempts Notification",
          "Multiple failed login attempts were detected on your account."
        );
        user.loginAttempts = 0;
        await user.save();
      }

      return res.status(400).json({ error: "Invalid credentials" });
    }

    // Reset login attempts on successful login
    user.loginAttempts = 0;
    await user.save();

    if (user.twoFactorEnabled) {
      return res.json({
        twoFactorRequired: true,
        message: "Enter the 2FA code",
      });
    }

    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );
    res.json({ message: "Login successful", token });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Login error" });
  }
});

// Verify 2FA
router.post("/verify-2fa", async (req, res) => {
  const { username, twoFactorCode } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user || !user.twoFactorSecret)
      return res
        .status(400)
        .json({ error: "2FA is not set up or user is invalid" });

    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: "base32",
      token: twoFactorCode,
      window: 2,
    });

    if (!verified) {
      return res.status(400).json({ error: "Invalid 2FA code" });
    }

    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );
    res.status(200).json({ message: "2FA verified successfully", token });
  } catch (error) {
    console.error("2FA verification error:", error);
    res.status(500).json({ error: "2FA verification error" });
  }
});

// Password reset
router.post("/forgot-password", async (req, res) => {
  const { username } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ error: "User not found" });

    const resetToken = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
      expiresIn: "15m",
    });
    const resetLink = `${process.env.CLIENT_URL}/reset-password?token=${resetToken}`;

    sendEmail(
      username,
      "Password Reset Request",
      `Click the following link to reset your password: ${resetLink}`
    );
    res.json({ message: "Password reset email sent" });
  } catch (error) {
    console.error("Password reset error:", error);
    res.status(500).json({ error: "Failed to send password reset email" });
  }
});

module.exports = router;
