const express = require("express");
const router = express.Router();
const PortfolioItem = require("../models/PortfolioItem");
const { verifyAdminRole } = require("../middleware/authMiddleware");

router.get("/admin", verifyAdminRole, async (req, res) => {
  try {
    const portfolioItems = await PortfolioItem.find();
    res.render("admin", { portfolioItems });
  } catch (error) {
    console.error("Error loading admin page:", error);
    res.status(500).send("Internal Server Error");
  }
});

module.exports = router;
