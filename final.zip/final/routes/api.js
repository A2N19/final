const express = require("express");
const axios = require("axios");
const router = express.Router();

const ALPHA_VANTAGE_API_KEY = process.env.ALPHA_VANTAGE_API_KEY;
const NEWS_API_KEY = process.env.NEWS_API_KEY;

// Route for fetching financial data from Alpha Vantage
router.get("/financial-data/:symbol", async (req, res) => {
  const symbol = req.params.symbol;
  try {
    const response = await axios.get(
      `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${ALPHA_VANTAGE_API_KEY}`
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: "Error fetching financial data" });
  }
});

// Route for fetching news from NewsAPI
router.get("/news/:topic", async (req, res) => {
  const topic = req.params.topic;
  try {
    const response = await axios.get(
      `https://newsapi.org/v2/everything?q=${topic}&apiKey=${NEWS_API_KEY}`
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: "Error fetching news data" });
  }
});

module.exports = router;
