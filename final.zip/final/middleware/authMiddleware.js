const jwt = require("jsonwebtoken");

function verifyEditorRole(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ error: "Authorization header is missing" });
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.role === "editor" || decoded.role === "admin") {
      req.user = decoded;
      return next();
    } else {
      return res
        .status(403)
        .json({ error: "Access denied: Insufficient role" });
    }
  } catch (error) {
    return res.status(403).json({ error: "Invalid or expired token" });
  }
}

function verifyAdminRole(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ error: "Authorization header is missing" });
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.role === "admin") {
      req.user = decoded;
      return next();
    } else {
      return res.status(403).json({ error: "Access denied: Admins only" });
    }
  } catch (error) {
    return res.status(403).json({ error: "Invalid or expired token" });
  }
}

module.exports = { verifyEditorRole, verifyAdminRole };
