const mongoose = require("mongoose");
const dotenv = require("dotenv");
const User = require("./models/User");

dotenv.config();

// Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("Connected to MongoDB Atlas"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Retrieve email and role from command-line arguments
const email = process.argv[2];
const role = process.argv[3];

if (!email || !role) {
  console.error("Usage: node assignRole.js <email> <role>");
  process.exit(1);
}

// Find user and update their role
async function assignRole() {
  try {
    const user = await User.findOne({ username: email });
    if (!user) {
      console.error(`User with email ${email} not found.`);
      process.exit(1);
    }

    user.role = role;
    await user.save();

    console.log(`Role "${role}" assigned to user ${email}.`);
    mongoose.connection.close();
  } catch (error) {
    console.error("Error assigning role:", error);
    mongoose.connection.close();
  }
}

assignRole();
