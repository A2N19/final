const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const path = require("path");
const dotenv = require("dotenv");
const authRoutes = require("./routes/auth");
const apiRoutes = require("./routes/api");
const portfolioRoutes = require("./routes/portfolio"); // Import portfolio route
const { verifyEditorRole } = require("./middleware/authMiddleware");
const adminRoutes = require("./routes/admin");
const nodemailer = require("nodemailer");

dotenv.config();

const app = express();

// Set EJS as the template engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views")); // Directory for EJS files

app.use("/portfolio/admin", adminRoutes);

// Configure Nodemailer for sending emails
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER, // Your email
    pass: process.env.EMAIL_PASS, // App Password (if using Gmail)
  },
});

function sendEmail(to, subject, text) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject,
    text,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Error sending email:", error);
    } else {
      console.log("Email sent:", info.response);
    }
  });
}

// Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("Connected to MongoDB Atlas"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public"))); // Serve static files

// Use routes
app.use("/api/auth", authRoutes);
app.use("/api", apiRoutes);
app.use("/portfolio", portfolioRoutes); // Attach portfolio route

// Protected routes restricted to editors
app.get(
  "/api/protected/financial-data/:symbol",
  verifyEditorRole,
  (req, res) => {
    res.json({ message: "Access granted to financial data" });
  }
);

app.get("/api/protected/news/:topic", verifyEditorRole, (req, res) => {
  res.json({ message: "Access granted to news data" });
});

// Main page
app.get("/", (req, res) => {
  res.render("index"); // Render the main page using EJS
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
