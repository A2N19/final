document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const formData = {
    username: document.getElementById("username").value,
    password: document.getElementById("password").value,
  };

  try {
    const response = await fetch("http://localhost:3000/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });

    const data = await response.json();

    if (response.ok && data.token) {
      document.getElementById("message").textContent =
        "Login successful! Redirecting...";
      localStorage.setItem("token", data.token); // Save the token for future requests

      // Redirect to the main page after successful login
      setTimeout(() => {
        window.location.href = "/portfolio"; // Redirect to the portfolio page
      }, 1000); // 1-second delay before redirecting to the portfolio page
    } else if (data.twoFactorRequired) {
      // If 2FA is required, display the 2FA input form
      show2FAForm();
    } else {
      document.getElementById("message").textContent =
        data.error || "Login failed.";
    }
  } catch (error) {
    document.getElementById("message").textContent =
      "An error occurred. Please try again.";
    console.error("Error:", error);
  }
});

// Function to display the 2FA form
function show2FAForm() {
  // Create an input field for the 2FA code
  const twoFactorInput = document.createElement("input");
  twoFactorInput.type = "text";
  twoFactorInput.id = "twoFactorCode";
  twoFactorInput.placeholder = "Enter 2FA code";
  document.getElementById("loginForm").appendChild(twoFactorInput);

  const submit2FAButton = document.createElement("button");
  submit2FAButton.textContent = "Submit 2FA Code";
  submit2FAButton.onclick = submit2FACode;
  document.getElementById("loginForm").appendChild(submit2FAButton);
}

// Function to submit the 2FA code
async function submit2FACode(e) {
  e.preventDefault();

  const formData = {
    username: document.getElementById("username").value,
    twoFactorCode: document.getElementById("twoFactorCode").value,
  };

  try {
    const response = await fetch("http://localhost:3000/api/auth/verify-2fa", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });

    const data = await response.json();

    if (response.ok && data.token) {
      document.getElementById("message").textContent =
        "2FA successful! Redirecting...";
      localStorage.setItem("token", data.token);

      setTimeout(() => {
        window.location.href = "/portfolio";
      }, 1000);
    } else {
      document.getElementById("message").textContent =
        data.error || "2FA verification failed.";
    }
  } catch (error) {
    document.getElementById("message").textContent =
      "An error occurred. Please try again.";
    console.error("Error:", error);
  }
}
