// app.js
document
  .getElementById("registrationForm")
  .addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = {
      username: document.getElementById("username").value,
      password: document.getElementById("password").value,
      firstName: document.getElementById("firstName").value,
      lastName: document.getElementById("lastName").value,
      age: document.getElementById("age").value,
      gender: document.getElementById("gender").value,
      twoFactorEnabled: document.getElementById("twoFactorEnabled").checked,
    };

    try {
      const response = await fetch("http://localhost:3000/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        document.getElementById("message").textContent =
          "Registration successful!";

        // If 2FA is enabled, display the QR code
        if (formData.twoFactorEnabled && data.qrCodeURL) {
          document.getElementById("qrCode").style.display = "block";
          document.getElementById("qrCodeImg").src = data.qrCodeURL;
        }
      } else {
        document.getElementById("message").textContent =
          data.error || "Registration failed.";
      }
    } catch (error) {
      document.getElementById("message").textContent =
        "An error occurred. Please try again.";
      console.error("Error:", error);
    }
  });

// public/app.js
document
  .getElementById("registrationForm")
  .addEventListener("submit", async (e) => {
    if (response.ok) {
      document.getElementById("message").textContent =
        "Registration successful! Redirecting to login...";
      setTimeout(() => {
        window.location.href = "/login.html";
      }, 2000);
    } else {
      document.getElementById("message").textContent =
        data.error || "Registration failed.";
    }
  });
