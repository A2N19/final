document
  .getElementById("itemForm")
  .addEventListener("submit", async (event) => {
    event.preventDefault();
    const title = document.getElementById("title").value;
    const description = document.getElementById("description").value;
    const images = Array.from(document.querySelectorAll(".image-url")).map(
      (input) => input.value.trim()
    );

    try {
      const response = await fetch("/portfolio", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({ title, description, images }),
      });

      if (response.ok) {
        alert("Item added successfully.");
        location.reload();
      } else {
        alert("Failed to add item.");
      }
    } catch (error) {
      console.error("Error adding item:", error);
    }
  });

async function editItem(id) {
  const title = prompt("Enter new title:");
  const description = prompt("Enter new description:");
  const images = prompt("Enter new image URLs (comma-separated):").split(",");

  try {
    const response = await fetch(`/portfolio/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify({ title, description, images }),
    });

    if (response.ok) {
      alert("Item updated successfully.");
      location.reload();
    } else {
      alert("Failed to update item.");
    }
  } catch (error) {
    console.error("Error updating item:", error);
  }
}

async function deleteItem(id) {
  if (!confirm("Are you sure you want to delete this item?")) return;

  try {
    const response = await fetch(`/portfolio/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    if (response.ok) {
      alert("Item deleted successfully.");
      location.reload();
    } else {
      alert("Failed to delete item.");
    }
  } catch (error) {
    console.error("Error deleting item:", error);
  }
}
