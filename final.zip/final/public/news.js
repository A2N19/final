async function fetchNewsData(topic) {
  const response = await fetch(`/api/news/${topic}`);
  const data = await response.json();
  return data.articles;
}

async function displayNewsChart(topic) {
  const articles = await fetchNewsData(topic);
  const sources = articles.map((article) => article.source.name);
  const sourceCounts = sources.reduce((acc, source) => {
    acc[source] = (acc[source] || 0) + 1;
    return acc;
  }, {});

  const sourceNames = Object.keys(sourceCounts);
  const counts = Object.values(sourceCounts);

  const ctx = document.getElementById("newsChart").getContext("2d");
  new Chart(ctx, {
    type: "bar",
    data: {
      labels: sourceNames,
      datasets: [
        {
          label: `News Sources for "${topic}"`,
          data: counts,
          backgroundColor: "rgba(153, 102, 255, 0.6)",
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        x: { display: true },
        y: { display: true },
      },
    },
  });
}

displayNewsChart("technology"); // Тема "технологии" для начальной визуализации
