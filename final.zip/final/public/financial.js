async function fetchFinancialData(symbol) {
  const response = await fetch(`/api/financial-data/${symbol}`);
  const data = await response.json();
  return data["Time Series (Daily)"];
}

async function displayFinancialChart(symbol) {
  const timeSeries = await fetchFinancialData(symbol);
  const dates = Object.keys(timeSeries).slice(0, 30).reverse();
  const prices = dates.map((date) => parseFloat(timeSeries[date]["4. close"]));

  const ctx = document.getElementById("financialChart").getContext("2d");
  new Chart(ctx, {
    type: "line",
    data: {
      labels: dates,
      datasets: [
        {
          label: `${symbol} Stock Price`,
          data: prices,
          borderColor: "rgba(75, 192, 192, 1)",
          fill: false,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        x: { display: true },
        y: { display: true },
      },
    },
  });
}

displayFinancialChart("AAPL");
