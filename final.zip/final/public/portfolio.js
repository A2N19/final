const portfolioItemsContainer = document.getElementById("portfolioItems");
const addNewItemButton = document.getElementById("addNewItemButton");
const portfolioFormModal = document.getElementById("portfolioFormModal");
const closeModal = document.getElementById("closeModal");
const itemForm = document.getElementById("itemForm");
const addImageButton = document.getElementById("addImageButton");
const imageInputsContainer = document.getElementById("imageInputsContainer");

// Validate and check required DOM elements
function checkDOMElements() {
  if (!portfolioItemsContainer)
    console.error("Error: portfolioItemsContainer not found.");
  if (!portfolioFormModal)
    console.error("Error: portfolioFormModal not found.");
  if (!closeModal) console.error("Error: closeModal not found.");
  if (!itemForm) console.error("Error: itemForm not found.");
}
checkDOMElements();

// Add a new image input dynamically
addImageButton?.addEventListener("click", () => {
  const newImageInput = document.createElement("input");
  newImageInput.type = "text";
  newImageInput.classList.add("image-url");
  newImageInput.placeholder = "Image URL";
  imageInputsContainer?.appendChild(newImageInput);
});

// Open modal to add a new item
addNewItemButton?.addEventListener("click", () => {
  portfolioFormModal.style.display = "flex";
});

// Close modal
closeModal?.addEventListener("click", () => {
  portfolioFormModal.style.display = "none";
});

// Render carousel for images
function renderCarousel(container, images, itemId) {
  const carouselContainer = document.createElement("div");
  carouselContainer.classList.add("carousel-container");
  carouselContainer.id = `carousel-${itemId}`;

  images.forEach((imageUrl, index) => {
    const img = document.createElement("img");
    img.src = imageUrl.trim();
    img.alt = `Image ${index + 1}`;
    img.classList.add("carousel-image");
    if (index === 0) img.classList.add("active");
    carouselContainer.appendChild(img);
  });

  const prevButton = document.createElement("button");
  prevButton.innerHTML = "&#9664;";
  prevButton.classList.add("carousel-button", "prev-button");
  prevButton.addEventListener("click", () => showPreviousImage(itemId));

  const nextButton = document.createElement("button");
  nextButton.innerHTML = "&#9654;";
  nextButton.classList.add("carousel-button", "next-button");
  nextButton.addEventListener("click", () => showNextImage(itemId));

  carouselContainer.appendChild(prevButton);
  carouselContainer.appendChild(nextButton);

  container.appendChild(carouselContainer);
}

// Show the next image in the carousel
function showNextImage(itemId) {
  const carousel = document.getElementById(`carousel-${itemId}`);
  const images = carousel.querySelectorAll(".carousel-image");
  let activeIndex = Array.from(images).findIndex((img) =>
    img.classList.contains("active")
  );

  images[activeIndex].classList.remove("active");
  activeIndex = (activeIndex + 1) % images.length;
  images[activeIndex].classList.add("active");
}

// Show the previous image in the carousel
function showPreviousImage(itemId) {
  const carousel = document.getElementById(`carousel-${itemId}`);
  const images = carousel.querySelectorAll(".carousel-image");
  let activeIndex = Array.from(images).findIndex((img) =>
    img.classList.contains("active")
  );

  images[activeIndex].classList.remove("active");
  activeIndex = (activeIndex - 1 + images.length) % images.length;
  images[activeIndex].classList.add("active");
}

// Fetch and display portfolio items
async function fetchAndDisplayPortfolioItems() {
  try {
    const response = await fetch("/portfolio/all", {
      method: "GET",
    });

    if (!response.ok) {
      console.error("Failed to fetch portfolio items:", await response.text());
      return;
    }

    const portfolioItems = await response.json();
    portfolioItemsContainer.innerHTML = "";

    portfolioItems.forEach((item) => {
      const itemDiv = document.createElement("div");
      itemDiv.classList.add("portfolio-item");

      const itemTitle = document.createElement("h3");
      itemTitle.textContent = item.title;

      const itemDescription = document.createElement("p");
      itemDescription.textContent = item.description;

      const carouselDiv = document.createElement("div");
      renderCarousel(carouselDiv, item.images, item._id);

      itemDiv.appendChild(itemTitle);
      itemDiv.appendChild(itemDescription);
      itemDiv.appendChild(carouselDiv);

      portfolioItemsContainer.appendChild(itemDiv);
    });
  } catch (error) {
    console.error("Error fetching portfolio items:", error);
  }
}

// Submit form to add a new portfolio item
itemForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const title = document.getElementById("title").value.trim();
  const description = document.getElementById("description").value.trim();
  const images = Array.from(document.querySelectorAll(".image-url"))
    .map((input) => input.value.trim())
    .filter((url) => url);

  if (!title || !description || images.length === 0) {
    alert("All fields are required.");
    return;
  }

  try {
    const response = await fetch("/portfolio", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ title, description, images }),
    });

    if (response.ok) {
      alert("Item added successfully.");
      portfolioFormModal.style.display = "none";
      fetchAndDisplayPortfolioItems();
      itemForm.reset();
      imageInputsContainer.innerHTML = "";
      const initialImageInput = document.createElement("input");
      initialImageInput.type = "text";
      initialImageInput.classList.add("image-url");
      initialImageInput.placeholder = "Image URL";
      imageInputsContainer.appendChild(initialImageInput);
    } else {
      const errorData = await response.json();
      alert(`Failed to add item: ${errorData.error}`);
    }
  } catch (error) {
    console.error("Error adding portfolio item:", error);
  }
});

// Close modal when clicking outside of it
window.addEventListener("click", (event) => {
  if (event.target === portfolioFormModal) {
    portfolioFormModal.style.display = "none";
  }
});

// Initialize portfolio fetching
fetchAndDisplayPortfolioItems();
